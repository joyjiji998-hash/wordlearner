WORD LEARNER WIDGET (Android / Samsung)

Option A - Android Studio (computer):
 1. Unzip, then File > Open the WordLearner folder in Android Studio and let it sync.
 2. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).
 3. On the phone: long-press the home screen > Widgets > Word Learner.

Option B - build online (no Android Studio):
 1. Create a free GitHub repository and upload the contents of this folder (keep the folders).
 2. Open the Actions tab > Build APK > Run workflow.
 3. When it finishes, download the WordLearner-apk artifact, unzip it, and install app-debug.apk
    on your phone (allow "install unknown apps" when asked). Then add the widget as in step 3 above.

Tap the widget for the next word. Drag its edges to resize. It also changes about every 30 minutes.
Words live in app/src/main/assets/words.txt (level|word|respelling|IPA|meaning|example).
