package com.wordlearner.widget

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = TextView(this)
        t.text = "Word Learner is installed.\n\nLong-press an empty spot on your home screen, tap Widgets, find Word Learner and add it.\n\nTap the widget for the next word. Drag its edges to resize it."
        t.textSize = 18f
        t.setPadding(48, 120, 48, 48)
        setContentView(t)
    }
}
