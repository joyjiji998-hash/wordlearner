package com.wordlearner.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class WordWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val p = context.getSharedPreferences("wl", Context.MODE_PRIVATE)
        val age = System.currentTimeMillis() - p.getLong("t", 0L)
        if (!p.contains("i") || age > 25 * 60 * 1000L) advance(context)
        draw(context, manager, ids)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_NEXT) {
            advance(context)
            val m = AppWidgetManager.getInstance(context)
            draw(context, m, m.getAppWidgetIds(ComponentName(context, WordWidget::class.java)))
        }
    }

    private fun words(context: Context): List<List<String>> =
        context.assets.open("words.txt").bufferedReader().readLines()
            .filter { it.isNotBlank() }.map { it.split("|") }

    private fun advance(context: Context) {
        val p = context.getSharedPreferences("wl", Context.MODE_PRIVATE)
        val n = words(context).size
        val cur = p.getInt("i", -1)
        var i = (0 until n).random()
        while (n > 1 && i == cur) i = (0 until n).random()
        p.edit().putInt("i", i).putLong("t", System.currentTimeMillis()).apply()
    }

    private fun draw(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val list = words(context)
        val p = context.getSharedPreferences("wl", Context.MODE_PRIVATE)
        val w = list[p.getInt("i", 0).coerceIn(0, list.size - 1)]
        val lv = w[0].toInt()
        val color = Color.parseColor(COLORS[lv])
        val rv = RemoteViews(context.packageName, R.layout.widget)
        rv.setTextViewText(R.id.level, LEVELS[lv])
        rv.setTextColor(R.id.level, color)
        rv.setTextViewText(R.id.word, w[1])
        rv.setTextViewText(R.id.pron, w[2] + "   " + w[3])
        rv.setTextColor(R.id.pron, color)
        rv.setTextViewText(R.id.meaning, w[4])
        rv.setTextViewText(R.id.example, w[5])
        val tap = PendingIntent.getBroadcast(
            context, 0,
            Intent(context, WordWidget::class.java).setAction(ACTION_NEXT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, tap)
        for (id in ids) manager.updateAppWidget(id, rv)
    }

    companion object {
        const val ACTION_NEXT = "com.wordlearner.widget.NEXT"
        val LEVELS = arrayOf("Medium", "Intermediate", "Advanced", "Very advanced")
        val COLORS = arrayOf("#2E8B6E", "#2F6FD0", "#7C4FC7", "#C2413F")
    }
}
